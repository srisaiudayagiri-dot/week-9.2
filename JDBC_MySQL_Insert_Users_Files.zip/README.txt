# JDBC MySQL Insert Users

## Files
- `InsertUsers.java` — Java program that creates the `users` table if needed and inserts two records with `PreparedStatement`.
- `setup.sql` — creates the database.
- `README.txt` — these instructions.

## Requirements
- A running MySQL server
- JDK 15 or later (the source uses a text block for the SQL statement)
- MySQL Connector/J JDBC driver

## 1. Create the database
Run `setup.sql` in MySQL, or execute:

    CREATE DATABASE IF NOT EXISTS mydatabase;

## 2. Configure credentials
Open `InsertUsers.java` and change `USERNAME` and `PASSWORD` to your MySQL credentials.
The default URL is `jdbc:mysql://localhost:3306/mydatabase`.

## 3. Compile and run
Make sure the MySQL Connector/J JAR is downloaded. Replace `mysql-connector-j.jar` below with its actual filename/path.

Windows:

    javac -cp ".;mysql-connector-j.jar" InsertUsers.java
    java -cp ".;mysql-connector-j.jar" InsertUsers

macOS/Linux:

    javac -cp ".:mysql-connector-j.jar" InsertUsers.java
    java -cp ".:mysql-connector-j.jar" InsertUsers

Expected output on success:

    Data inserted successfully.

Running the program again inserts the same two records again; the table does not enforce unique email addresses in this example.
